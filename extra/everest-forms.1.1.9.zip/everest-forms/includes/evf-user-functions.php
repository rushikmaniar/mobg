<?php
/**
 * EverestForms User Functions
 *
 * Functions for users.
 *
 * @author        WPEverest
 * @category      Core
 * @package       EverestForms/Functions
 * @version       1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
